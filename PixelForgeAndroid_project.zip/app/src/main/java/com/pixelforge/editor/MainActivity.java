package com.pixelforge.editor;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.content.ContentResolver;
import android.util.Base64;
import android.widget.Toast;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView web;
    private static final int PICK_PNG = 101, SAVE_PNG = 102;
    private String pendingPng = null;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(0xff10151d);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private class Bridge {
        @JavascriptInterface public void importPng() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                startActivityForResult(i, PICK_PNG);
            });
        }
        @JavascriptInterface public void exportPng(String dataUrl, String filename) {
            runOnUiThread(() -> {
                if (dataUrl == null || !dataUrl.startsWith("data:image/png;base64,")) {
                    Toast.makeText(MainActivity.this, "Не удалось подготовить PNG", Toast.LENGTH_SHORT).show(); return;
                }
                pendingPng = dataUrl.substring(dataUrl.indexOf(',') + 1);
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/png");
                i.putExtra(Intent.EXTRA_TITLE, filename == null ? "texture.png" : filename);
                startActivityForResult(i, SAVE_PNG);
            });
        }
        @JavascriptInterface public void toast(String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_PNG) {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                String mime = getContentResolver().getType(uri);
                String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                String js = "window.loadImportedImage('data:" + (mime == null ? "image/png" : mime) + ";base64," + b64 + "')";
                web.evaluateJavascript(js, null);
            } catch (Exception e) { Toast.makeText(this, "Не удалось открыть изображение", Toast.LENGTH_LONG).show(); }
        } else if (requestCode == SAVE_PNG && pendingPng != null) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                out.write(Base64.decode(pendingPng, Base64.DEFAULT));
                Toast.makeText(this, "PNG сохранён", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "Не удалось сохранить PNG", Toast.LENGTH_LONG).show(); }
            pendingPng = null;
        }
    }
}
