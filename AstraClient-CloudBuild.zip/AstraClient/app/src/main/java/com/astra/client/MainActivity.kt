package com.astra.client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.pow

private val Night = Color(0xFF06111F)
private val Panel = Color(0xFF0C1D30)
private val Cyan = Color(0xFF00D9FF)
private val Muted = Color(0xFF9CB6CC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AstraApp() }
    }
}

@Composable
private fun AstraApp() {
    var page by remember { mutableStateOf("Главная") }
    var showHud by remember { mutableStateOf(true) }
    var showFps by remember { mutableStateOf(true) }
    var showPing by remember { mutableStateOf(true) }
    var touchScale by remember { mutableFloatStateOf(1f) }
    var pearlSpeed by remember { mutableFloatStateOf(1.0f) }
    var pearlAngle by remember { mutableFloatStateOf(45f) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Night, surface = Panel)) {
        Row(Modifier.fillMaxSize().background(Night)) {
            Column(Modifier.width(190.dp).fillMaxHeight().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(36.dp).background(Cyan, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                        Text("A", color = Night, fontWeight = FontWeight.Black, fontSize = 24.sp)
                    }
                    Column {
                        Text("ASTRA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Text("CLIENT  •  BETA", color = Cyan, fontSize = 9.sp, letterSpacing = 1.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                listOf("Главная", "HUD", "Управление", "Траектория", "О клиенте").forEach { item ->
                    Row(
                        Modifier.fillMaxWidth().background(if (page == item) Color(0xFF103752) else Color.Transparent, RoundedCornerShape(12.dp))
                            .clickable { page = item }.padding(horizontal = 12.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(when(item) { "Главная" -> "⌂"; "HUD" -> "⊙"; "Управление" -> "▦"; "Траектория" -> "〰"; else -> "ⓘ" }, color = Cyan, fontSize = 18.sp)
                        Spacer(Modifier.width(10.dp))
                        Text(item, color = if (page == item) Color.White else Muted, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("NO CHEATS • NO INJECTION", color = Muted, fontSize = 9.sp)
                Text("v0.1.0 • ANDROID", color = Cyan, fontSize = 10.sp)
            }
            Column(Modifier.fillMaxSize().padding(start = 4.dp, end = 18.dp, top = 18.dp, bottom = 18.dp)) {
                Text(page.uppercase(), color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("Твой стиль. Твоя игра.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                when (page) {
                    "Главная" -> HomePage(onOpen = { page = it })
                    "HUD" -> HudPage(showHud, { showHud = it }, showFps, { showFps = it }, showPing, { showPing = it })
                    "Управление" -> ControlsPage(touchScale) { touchScale = it }
                    "Траектория" -> TrajectoryPage(pearlSpeed, { pearlSpeed = it }, pearlAngle, { pearlAngle = it })
                    else -> AboutPage()
                }
            }
        }
    }
}

@Composable
private fun HomePage(onOpen: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxSize()) {
        Column(Modifier.weight(1.25f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            CardBox(Modifier.fillMaxWidth()) {
                Text("ЛЕГАЛЬНЫЙ COMPANION", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Astra Client", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("Инструменты и настройки для Minecraft Bedrock на Android.", color = Muted, fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                Text("✓  Без внедрения в игру", color = Color(0xFF76E6B0), fontSize = 12.sp)
                Text("✓  Без обхода античита", color = Color(0xFF76E6B0), fontSize = 12.sp)
                Text("✓  Настройки сохраняются в рамках сессии", color = Color(0xFF76E6B0), fontSize = 12.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FeatureCard("HUD", "Персональные настройки", Modifier.weight(1f)) { onOpen("HUD") }
                FeatureCard("MOBILE", "Масштаб управления", Modifier.weight(1f)) { onOpen("Управление") }
                FeatureCard("ARC", "Расчёт траектории", Modifier.weight(1f)) { onOpen("Траектория") }
            }
        }
        Column(Modifier.weight(0.8f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            CardBox(Modifier.fillMaxWidth().weight(1f)) {
                Text("ПРЕДПРОСМОТР HUD", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                Box(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF13283A), RoundedCornerShape(14.dp)).padding(12.dp)) {
                    Column(Modifier.align(Alignment.TopStart)) {
                        Text("ASTRA • PREVIEW", color = Muted, fontSize = 10.sp)
                        Text("FPS: 60    Ping: —", color = Color.White, fontSize = 12.sp)
                    }
                    Column(Modifier.align(Alignment.BottomCenter), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("+", color = Cyan, fontSize = 26.sp, fontWeight = FontWeight.Light)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { repeat(9) { Box(Modifier.size(20.dp, 22.dp).background(if (it == 0) Cyan else Color(0xFF28445B), RoundedCornerShape(4.dp))) } }
                    }
                    Text("Демо · не подключено к игре", Modifier.align(Alignment.BottomStart), color = Muted, fontSize = 10.sp)
                }
            }
            Text("Важно: это companion-приложение. Оно не получает автоматически здоровье противников или игровые координаты.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun HudPage(showHud: Boolean, onHud: (Boolean) -> Unit, showFps: Boolean, onFps: (Boolean) -> Unit, showPing: Boolean, onPing: (Boolean) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxSize()) {
        CardBox(Modifier.weight(1f)) {
            Text("ЭЛЕМЕНТЫ ПРЕДПРОСМОТРА", color = Cyan, fontWeight = FontWeight.Bold)
            SettingSwitch("Показывать демо-HUD", "Внутри приложения", showHud, onHud)
            SettingSwitch("Показывать FPS", "Демонстрационный индикатор", showFps, onFps)
            SettingSwitch("Показывать ping", "Пока без подключения к игре", showPing, onPing)
        }
        CardBox(Modifier.weight(1f)) {
            Text("ПРЕДПРОСМОТР", color = Cyan, fontWeight = FontWeight.Bold)
            if (showHud) {
                if (showFps || showPing) Text(listOfNotNull(if (showFps) "FPS: 60" else null, if (showPing) "Ping: —" else null).joinToString("     "), color = Color.White)
                Spacer(Modifier.height(16.dp))
                Text("Цель: недоступна", color = Muted, fontSize = 13.sp)
                Text("❤  ❤  ❤  ❤  ❤", color = Cyan, fontSize = 19.sp)
            } else Text("HUD скрыт", color = Muted)
            Spacer(Modifier.height(12.dp))
            Text("Показатели сейчас демонстрационные, а не реальные данные Minecraft.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ControlsPage(scale: Float, onScale: (Float) -> Unit) {
    CardBox(Modifier.fillMaxWidth()) {
        Text("МОБИЛЬНОЕ УПРАВЛЕНИЕ", color = Cyan, fontWeight = FontWeight.Bold)
        Text("Настройка масштаба для макета управления внутри Astra.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Text("Размер кнопок: ${(scale * 100).toInt()}%", color = Color.White)
        Slider(value = scale, onValueChange = onScale, valueRange = 0.75f..1.35f)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("◀", "▼", "▶", "▲", "⚔").forEach { key ->
                Box(Modifier.size((42 * scale).dp).background(Color(0xFF18354B), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                    Text(key, color = Cyan, fontSize = 18.sp)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Примечание: настройки не изменяют сенсорные кнопки внутри Minecraft. Это демонстрация будущего companion-инструмента.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun TrajectoryPage(speed: Float, onSpeed: (Float) -> Unit, angle: Float, onAngle: (Float) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxSize()) {
        CardBox(Modifier.weight(1f)) {
            Text("ТРАЕКТОРИЯ БРОСКА", color = Cyan, fontWeight = FontWeight.Bold)
            Text("Учебная физическая модель — не считывает игру.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text("Начальная скорость: ${"%.1f".format(speed)}", color = Color.White)
            Slider(value = speed, onValueChange = onSpeed, valueRange = 0.5f..2f)
            Text("Угол: ${angle.toInt()}°", color = Color.White)
            Slider(value = angle, onValueChange = onAngle, valueRange = 15f..75f)
            Text("В реальном Bedrock скорость и физика могут отличаться в зависимости от версии и сервера.", color = Muted, fontSize = 11.sp)
        }
        CardBox(Modifier.weight(1.2f)) {
            Text("СХЕМА ПОЛЁТА", color = Cyan, fontWeight = FontWeight.Bold)
            Canvas(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF081522), RoundedCornerShape(12.dp)).padding(8.dp)) {
                val w = size.width; val h = size.height
                drawLine(Color(0xFF27475D), Offset(12f, h - 18f), Offset(w - 12f, h - 18f), strokeWidth = 2f)
                val rad = Math.toRadians(angle.toDouble())
                val vx = speed * kotlin.math.cos(rad).toFloat()
                val vy = speed * kotlin.math.sin(rad).toFloat()
                val points = (0..60).map { i ->
                    val t = i / 60f * 2.2f
                    val x = 18f + (w - 40f) * (i / 60f)
                    val yModel = (vy * t - 0.5f * 0.85f * t.pow(2))
                    Offset(x, (h - 24f - yModel * 48f).coerceIn(10f, h - 22f))
                }
                for (i in 0 until points.lastIndex) {
                    if (i % 2 == 0) drawLine(Cyan, points[i], points[i + 1], strokeWidth = 3f)
                }
                drawCircle(Color.White, radius = 6f, center = points.first())
                drawCircle(Cyan, radius = 7f, center = points.last())
            }
            Text("Пунктир — пример расчёта параболы. Это не точная траектория эндер-жемчуга в игре.", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun AboutPage() {
    CardBox(Modifier.fillMaxWidth()) {
        Text("ОБ ASTRA CLIENT", color = Cyan, fontWeight = FontWeight.Bold)
        Text("Astra — независимое приложение-компаньон для Android. Оно не является официальным продуктом Mojang или Microsoft.", color = Color.White)
        Spacer(Modifier.height(10.dp))
        Text("Текущий прототип не подключается к Minecraft, не внедряет код, не меняет игровые файлы и не обходит античит.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Text("Следующий этап: определить безопасный способ интеграции с поддерживаемыми ресурс-паками и внешними инструментами, не заявляя о функциях, которых Android/Bedrock не предоставляет.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun CardBox(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
private fun FeatureCard(title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(12.dp)) {
        Text(title, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
