# Astra Client — Android prototype

A Kotlin + Jetpack Compose starter project for a legal Minecraft Bedrock companion app.

## Included
- Landscape Android interface with dark navy / cyan styling
- Demo HUD toggles (values are placeholders, not read from Minecraft)
- In-app mobile-control size preview
- Educational projectile-arc visualizer with adjustable speed and angle
- Explicit no-injection / no-anticheat-bypass positioning

## Important limitations
This project does **not** connect to Minecraft Bedrock, read opponent health, obtain live FPS/ping, overlay the game, or calculate the exact in-game Ender Pearl path. Those capabilities are not available to an ordinary companion app without a supported integration. The trajectory page is an educational approximation, not a gameplay aid connected to a live session.

## Build
1. Install Android Studio with Android SDK 35 and a compatible JDK (17 recommended).
2. Open this folder in Android Studio.
3. Let Gradle sync, then run the `app` configuration on an Android device or emulator.

This is source code, not a prebuilt APK. No Mojang/Microsoft assets are included; Minecraft is a trademark of its respective owner.

## Сборка APK без компьютера (через Android и GitHub)

Этот репозиторий настроен на облачную сборку **debug APK**. Для сборки не нужен ПК, но нужен аккаунт GitHub и браузер на телефоне.

### 1. Создай репозиторий
1. Открой https://github.com/new в браузере телефона и войди в GitHub.
2. Назови репозиторий `AstraClient`.
3. Выбери **Public** (так проще новичку) или **Private**, затем нажми **Create repository**.
4. Не добавляй README, .gitignore или лицензию, чтобы создать пустой репозиторий.

### 2. Загрузи файлы проекта
1. Распакуй этот ZIP на телефоне с помощью файлового менеджера, который умеет распаковывать ZIP.
2. Открой созданный репозиторий на GitHub в браузере.
3. Нажми **Add file → Upload files**.
4. Загрузить нужно *содержимое папки `AstraClient`*, включая скрытую папку `.github/workflows` и файл `build-apk.yml`. Если телефон не показывает скрытые папки или браузер не позволяет загрузить папку целиком, используй GitHub Codespaces/веб-редактор либо загрузку через приложение/терминал, поддерживающий Git.
5. Нажми **Commit changes**.

Важно: workflow должен находиться именно по пути `.github/workflows/build-apk.yml` в корне репозитория, а `settings.gradle.kts`, `build.gradle.kts` и папка `app` тоже должны быть в корне репозитория, не внутри дополнительной вложенной папки `AstraClient`.

### 3. Запусти сборку
1. На странице репозитория открой вкладку **Actions**.
2. Выбери workflow **Build Astra Client APK**.
3. Если GitHub попросит включить Actions, подтверди.
4. Нажми **Run workflow → Run workflow**. Также сборка автоматически запускается после загрузки коммита в ветку `main`.
5. Дождись зелёной отметки успешного завершения.

### 4. Скачай APK на телефон
1. Открой завершённый запуск в **Actions**.
2. Прокрути до **Artifacts**.
3. Нажми `AstraClient-debug-apk` — скачается ZIP-архив с APK.
4. Распакуй архив и открой APK. Если Android спросит, разреши установку приложений из этого источника в системных настройках, затем вернись к установке.

### Если сборка не запускается
- Убедись, что workflow лежит в `.github/workflows/build-apk.yml`.
- Убедись, что файлы Gradle лежат в корне репозитория.
- Проверь, что Actions разрешены в настройках репозитория.
- Открой журнал упавшего шага и сохрани текст ошибки для диагностики.

### Ограничения
- Это **debug APK**, не подписанный отдельным релизным ключом; его можно установить для тестирования, но для публичного распространения нужна отдельная release-сборка с надёжным хранением ключа подписи.
- APK — самостоятельное приложение-компаньон. Оно не внедряется в Minecraft, не считывает скрытые игровые данные и не рисует системный HUD поверх игры.
- Визуализация траектории в этой версии — демонстрационная модель внутри Astra Client, а не реальная траектория в игровом мире.
